# SPEC-10-RAYD-Scientific-Calculator-V10

## Background

V10 removes the solar-style header panel and fixes remaining visible fraction-editor bugs.

## Requirements

### Must Have

- RAYD branding only.
- No Casio branding, model names, logos, or copied product artwork.
- No decorative solar panel.
- Left-aligned natural expression display.
- Fraction behavior: `9 → a/b` creates 9 over blank denominator.
- `DEL` / backspace must not expose raw `fra` or `frac` text.
- Arrow behavior:
  - `▲` moves to upper template slot.
  - `▼` moves to lower template slot.
  - `▶` exits template.
- ENG/SCI display uses superscript `×10³` formatting.

### Should Have

- Compact original hardware-inspired layout.
- Mode/setup menus.
- STAT quick functions.

## Method

Architecture:

```text
Jetpack Compose UI
        ↓
Natural Editor State
        ↓
CalculatorEngine Parser
        ↓
Result Formatter
```

V10 keeps the parser-based evaluation engine and patches the UI/editor behavior.

## Implementation

- Update app version to 10.0.0.
- Remove solar panel composables and colors.
- Add natural display sanitization for incomplete `frac` fragments.
- Add editor cleanup after DEL/backspace.

## Milestones

1. Build debug APK.
2. Test header: no solar panel visible.
3. Test `25×4 → a/b → DEL` and verify no `fra` text appears.
4. Test `9 → a/b → ▼ → 3 → =`.
5. Test `1000 → ENG`.

## Gathering Results

Manual test cases:

```text
Header                   no solar panel
(25×4)+a/b then DEL       no raw fra/frac text visible
9 → a/b → 3 → =           should equal 3
1000 → ENG                should show 1×10³
1000000 → ENG             should show 1×10⁶
sin(30) DEG               should be 0.5
```

## Need Professional Help in Developing Your Architecture?

Please contact me at [sammuti.com](https://sammuti.com) :)


## V11 update

- After `=` / OK, `DEL` is locked so it does not delete the completed calculation.
- Press `AC` to clear, or press arrow keys to enter edit mode before deleting.
- Solar panel remains removed from the clean RAYD header.


## V12 Update

- MODE button now opens an 8-option Casio-style mode screen: COMP, CMPLX, STAT, BASE-N, EQN, MATRIX, TABLE, VECTOR.
- SETUP menu screen layout cleaned.
- Result line hides while menus are open, so the menu is easier to read.


## RAYD V15 Update

- Pressing `x⁻¹` now opens a Natural Display reciprocal template.
- Blank `x⁻¹` shows `□⁻¹` with the cursor in the base slot.
- `5 → x⁻¹` converts to `5⁻¹` and evaluates as `1/5`.


## V15 Clear-State Fix

- AC clears expression, result preview, history preview, template state, and ENG preview.
- Ans remains stored internally but old ENG/result text is not displayed after AC.
