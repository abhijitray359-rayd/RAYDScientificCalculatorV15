# RAYD Scientific Calculator V10

RAYD V13 - Natural Integral Templatenal hardware-inspired Android scientific calculator.

## V10 fixes

- Removed the decorative solar panel from the header.
- Kept RAYD branding and compact status text only.
- Added UI protection so incomplete fraction fragments such as `fra` / `frac` are not shown after DEL/backspace.
- Kept V9 fixes:
  - thin text-level cursor
  - `9 → a/b` creates 9 over blank denominator
  - `▼` moves to denominator
  - `▲` moves to numerator
  - `▶` exits the current template
  - ENG/SCI display uses `×10³` superscript style

## Build on GitHub from phone

Upload `RAYDScientificCalculator_v10_source.zip`, then create:

`.github/workflows/build-rayd.yml`

Run **Actions → Build RAYD APK → Run workflow**.

The APK artifact name is `rayd-debug-apk`.


## V11 update

- After `=` / OK, `DEL` is locked so it does not delete the completed calculation.
- Press `AC` to clear, or press arrow keys to enter edit mode before deleting.
- Solar panel remains removed from the clean RAYD header.


## V12 Update

- MODE button now opens an 8-option Casio-style mode screen: COMP, CMPLX, STAT, BASE-N, EQN, MATRIX, TABLE, VECTOR.
- SETUP menu screen layout cleaned.
- Result line hides while menus are open, so the menu is easier to read.


## V13
- ∫dx now opens a natural integral template with upper limit, lower limit, integrand box, and dx.
- Cursor starts in the integrand slot; ▼ moves through the template arguments and ▶ exits.


## RAYD V15 Update

- Pressing `x⁻¹` now opens a Natural Display reciprocal template.
- Blank `x⁻¹` shows `□⁻¹` with the cursor in the base slot.
- `5 → x⁻¹` converts to `5⁻¹` and evaluates as `1/5`.


## V15 Clear-State Fix

- AC clears expression, result preview, history preview, template state, and ENG preview.
- Ans remains stored internally but old ENG/result text is not displayed after AC.
